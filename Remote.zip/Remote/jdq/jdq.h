#ifndef __JDQ_H
#define __JDQ_H
#include "main.h"
#include "gpio.h"
#include "remote_control.h"
#include "bsp_can.h"
#include "pid.h"
#include "can.h"
#include "CAN_recieve.h"

void yk_start(void);
void all_light(void);
void auto_start(void);
void f_start(void);
void all_close(void);
void motor_start(void);
void big_motor(void);
void nop_delay_ms(uint16_t ms);
extern float set_speed;
#endif
