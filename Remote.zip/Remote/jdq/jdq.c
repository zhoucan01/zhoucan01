#include "jdq.h"
#include "main.h"
#include "gpio.h"
#include "remote_control.h"
#include "bsp_can.h"
#include "pid.h"
#include "can.h"
#include "CAN_recieve.h"
#include "pid.h"
#include "cmath"
#include "rng.h"
#include "cmsis_os.h"
#include "freertos.h"
#include "jdq.h"
#define amax 10


//void print_task(void const * argument)
//{
//	while(1)
//	{
//	
//	printf(%f,%f,%f,%f,);
//	osDelay(5);
//	}

//}

int bbbbbbbb;
float set_speed;
void print_task(void const * argument)
{
	for(;;)
  {
		bbbbbbbb++;
		printf("%f,%f,%f\n",get_speed0,set_speed,get_speed1);
    osDelay(3);
  }
}


// int t, num;
// float spd, a, w, b;
// int y = 0;

// void blink()
// {
//     HAL_GPIO_TogglePin(GPIOG, GPIO_PIN_All);
//     HAL_Delay(500);
// }

// void jdq_start()
// {
//     int i;
//     int count = 11;
//     if (rc_ctrl.rc.s_r == 1)
//         for (i = 0; i <= 10; i++)
//         {
//             HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, 1);
//             HAL_Delay(2500);
//         }
//     for (i = 1; i < 10; i++)
//     {

//         HAL_GPIO_WritePin(GPIOF, I1_Pin, 1);
//         HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, 1);
//         HAL_Delay(2500);
//     }
//     for (i = 2; i < count; i++)
//     {
//         HAL_GPIO_WritePin(GPIOF, I1_Pin, 1);
//         HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, 1);
//         HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, 1);
//         HAL_Delay(2500);
//     }
//     for (i = 3; i < count; i++)
//     {
//         HAL_GPIO_WritePin(GPIOF, I1_Pin, 1);
//         HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, 1);
//         HAL_GPIO_WritePin(J1_GPIO_Port, J1_Pin, 1);
//         HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, 1);
//         HAL_Delay(2500);
//     }

//     if (rc_ctrl.rc.s_r == 1)
//         HAL_GPIO_WritePin(I2_GPIO_Port, I1_Pin | I2_Pin, 0);
//     HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin | J2_Pin, 0);
// }

// void led_start()
// {
//     int a = 0;

//     if (a == 0)
//     {
//         HAL_GPIO_WritePin(GPIOG, GPIO_PIN_1, 1);
//         HAL_Delay(2500);
//         a++;
//     }
//     if (a == 1)
//     {
//         HAL_GPIO_WritePin(GPIOG, GPIO_PIN_1, 1);
//         HAL_GPIO_WritePin(GPIOG, GPIO_PIN_2, 1);
//         HAL_Delay(2500);
//         a++;
//     }
//     if (a == 2)
//     {
//         HAL_GPIO_WritePin(GPIOG, GPIO_PIN_1, 1);
//         HAL_GPIO_WritePin(GPIOG, GPIO_PIN_2, 1);
//         HAL_GPIO_WritePin(GPIOG, GPIO_PIN_3, 1);
//         HAL_Delay(2500);
//         a++;
//     }
//     if (a == 3)
//     {
//         HAL_GPIO_WritePin(GPIOG, GPIO_PIN_1, 1);
//         HAL_GPIO_WritePin(GPIOG, GPIO_PIN_2, 1);
//         HAL_GPIO_WritePin(GPIOG, GPIO_PIN_3, 1);
//         HAL_GPIO_WritePin(GPIOG, GPIO_PIN_4, 1);

//         HAL_Delay(2500);
//         a++;
//     }
//     if (a == 4)
//     {
//         HAL_GPIO_WritePin(GPIOG, GPIO_PIN_1, 1);
//         HAL_GPIO_WritePin(GPIOG, GPIO_PIN_2, 1);
//         HAL_GPIO_WritePin(GPIOG, GPIO_PIN_3, 1);
//         HAL_GPIO_WritePin(GPIOG, GPIO_PIN_4, 1);
//         HAL_GPIO_WritePin(GPIOG, GPIO_PIN_5, 1);
//         HAL_Delay(2500);
//         a++;
//     }
//     if (a == 5)
//     {
//         HAL_GPIO_TogglePin(GPIOG, GPIO_PIN_All);
//         HAL_Delay(2500);
//         a = 0;
//     }
// }

void f_start(void)
{
    int x = 0;

    if (x == 0)
    {
        HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
        HAL_Delay(2500);
        x++;
    }

    if (x == 1)
    {
        HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
        HAL_Delay(2500);
        x++;
    }

    if (x == 2)
    {
        HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
        HAL_Delay(2500);
        x++;
    }

    if (x == 3)
    {
        HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K2_GPIO_Port, K2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(L1_GPIO_Port, L1_Pin, GPIO_PIN_SET);
        HAL_Delay(2500);
        x++;
    }
    if (x == 4)
    {
        HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K2_GPIO_Port, K2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(L1_GPIO_Port, L1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(L2_GPIO_Port, L2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, GPIO_PIN_SET);
        HAL_Delay(2500);
        x++;
    }
    if (x == 5)
    {
        HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K2_GPIO_Port, K2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(L1_GPIO_Port, L1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(L2_GPIO_Port, L2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(M2_GPIO_Port, M2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(N1_GPIO_Port, N1_Pin, GPIO_PIN_SET);
        HAL_Delay(2500);
        x++;
    }
    if (x == 6)
    {
        HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K2_GPIO_Port, K2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(L1_GPIO_Port, L1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(L2_GPIO_Port, L2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(M2_GPIO_Port, M2_Pin, GPIO_PIN_SET);
        HAL_Delay(2500);
        x++;
    }
    if (x == 7)
    {
        HAL_GPIO_TogglePin(I1_GPIO_Port, I1_Pin);
        HAL_GPIO_TogglePin(I2_GPIO_Port, I2_Pin);
        HAL_GPIO_TogglePin(J1_GPIO_Port, J1_Pin);
        HAL_GPIO_TogglePin(J2_GPIO_Port, J2_Pin);
        HAL_GPIO_TogglePin(K1_GPIO_Port, K1_Pin);
        HAL_GPIO_TogglePin(K2_GPIO_Port, K2_Pin);
        HAL_GPIO_TogglePin(L1_GPIO_Port, L1_Pin);
        HAL_GPIO_TogglePin(L2_GPIO_Port, L2_Pin);
        HAL_GPIO_TogglePin(M1_GPIO_Port, M1_Pin);
        HAL_GPIO_TogglePin(M2_GPIO_Port, M2_Pin);
        HAL_Delay(10);
        x = 0;
    }
}

void yk_start(void)
{
int y;
    if (rc_ctrl.rc.s_l == 3 && rc_ctrl.rc.ch0 > 650)
    {

        HAL_Delay(100);
        y++;
    }
    if (rc_ctrl.rc.s_l == 3 && rc_ctrl.rc.ch0 < -650)
    {
        all_close();
        y = 0;
    }
    if (y == 0)
    {
        HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
    }
		
    if (y == 1)
    {
        HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
    }

    if (y == 2)
    {
        HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
    }

    if (y == 3)
    {
        HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K2_GPIO_Port, K2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(L1_GPIO_Port, L1_Pin, GPIO_PIN_SET);
    }
    if (y == 4)
    {
        HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K2_GPIO_Port, K2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(L1_GPIO_Port, L1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(L2_GPIO_Port, L2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, GPIO_PIN_SET);
    }
    if (y == 5)
    {
        HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K2_GPIO_Port, K2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(L1_GPIO_Port, L1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(L2_GPIO_Port, L2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(M2_GPIO_Port, M2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(N1_GPIO_Port, N1_Pin, GPIO_PIN_SET);
    }
    if (y == 6)
    {
        HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(K2_GPIO_Port, K2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(L1_GPIO_Port, L1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(L2_GPIO_Port, L2_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, GPIO_PIN_SET);
        HAL_GPIO_WritePin(M2_GPIO_Port, M2_Pin, GPIO_PIN_SET);
    }
    if (y == 7)
    {
        HAL_GPIO_TogglePin(I1_GPIO_Port, I1_Pin);
        HAL_GPIO_TogglePin(I2_GPIO_Port, I2_Pin);
        HAL_GPIO_TogglePin(J1_GPIO_Port, J1_Pin);
        HAL_GPIO_TogglePin(J2_GPIO_Port, J2_Pin);
        HAL_GPIO_TogglePin(K1_GPIO_Port, K1_Pin);
        HAL_GPIO_TogglePin(K2_GPIO_Port, K2_Pin);
        HAL_GPIO_TogglePin(L1_GPIO_Port, L1_Pin);
        HAL_GPIO_TogglePin(L2_GPIO_Port, L2_Pin);
        HAL_GPIO_TogglePin(M1_GPIO_Port, M1_Pin);
        HAL_GPIO_TogglePin(M2_GPIO_Port, M2_Pin);
        y = 0;
    }
}

void all_light(void)
{
    HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(J1_GPIO_Port, J1_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(K2_GPIO_Port, K2_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(L1_GPIO_Port, L1_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(L2_GPIO_Port, L2_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(M2_GPIO_Port, M2_Pin, GPIO_PIN_SET);
}

void all_close(void)
{
    HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(J1_GPIO_Port, J1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(K2_GPIO_Port, K2_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(L1_GPIO_Port, L1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(L2_GPIO_Port, L2_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(M2_GPIO_Port, M2_Pin, GPIO_PIN_RESET);
}
void auto_start(void)
{
    if (rc_ctrl.rc.s_l == 1)
    { 
        // all_close();

        f_start();
    }
}

void motor_start(void)
{
//小符模式
    if (rc_ctrl.rc.s_r == 1)
    {

        motor[1].set_current = pid_calc(&pid[SPEED], motor[1].speed_rpm, 1000);
        set_motor_current(&hcan1, 0x200, motor[1].set_current, 0, 0, 0);
        HAL_Delay(10);
    }
		
		//停止模式
    if (rc_ctrl.rc.s_r == 3)
    {
        motor[1].set_current = pid_calc(&pid[SPEED], motor[1].speed_rpm, 0);
        set_motor_current(&hcan1, 0x200, 0, 0, 0, 0);
        HAL_Delay(10);
    }
		
		
		
		
    //随机数
    // num = HAL_RNG_GetRandomNumber(&hrng);
    // a = (num % 274 + 780);
    // a = a / 1000;
    // w = (num % 116 + 1884);
    // w = w / 1000;
    // b = 2.090f - a;
    // // t = t + 1;
    // spd = (a * sin(w * t) + b) * 9.554;
		
		
//大符模式
    if (rc_ctrl.rc.s_r == 2)
    {  
        // a >= 0.780f && a <= 1.054f;
        // w >= 1.884f && w <= 2.000f;
        // 1 Rad/sec = 9.55 RPM
        // motor[1].set_current = pid_calc(&pid[SPEED], motor[1].speed_rpm, spd * 90);
        // set_motor_current(&hcan1, 0x200, motor[1].set_current, 0, 0, 0);
        // HAL_Delay(820);
        // t = t + 1;
    }
    if (rc_ctrl.rc.s_r != 2)
    {
      //  t = 0;
    }
    //    HAL_Delay(10);
}

// void big_motor(void)
// {
//     int t;
//     float spd, a, w, b;
//     a >= 0.780f && a <= 1.054f;
//     w >= 1.884f && w <= 2.000f;
//     b = 2.090f - a;
//     spd = a * sin(w * t) + b;

//     if (rc_ctrl.rc.s_r == 2)
//     {
//         motor[1].set_current = pid_calc(&pid[SPEED], motor[1].speed_rpm, spd*950);
//         set_motor_current(&hcan1, 0x200, 0, 0, 0, 0);
//         HAL_Delay(10);
//     }
// }

void nop_delay_us(uint16_t us)
{
    for (; us > 0; us--)
    {
        for (uint8_t i = 10; i > 0; i--)
        {
            __nop();
            __nop();
            __nop();
            __nop();
            __nop();
            __nop();
            __nop();
            __nop();
            __nop();
            __nop();
            __nop();
            __nop();
            __nop();
            __nop();
            __nop();
        }
    }
}
void nop_delay_ms(uint16_t ms)
{
    for (; ms > 0; ms--)
    {
        nop_delay_us(1000);
    }
}

