#ifndef __PID_H
#define __PID_H

#ifndef NULL
#define NULL 0
#endif

#include "struct_typedef.h"
#include "math.h"

#define SPEED 0
#define ANGLE 1

#define SET_CURRENT_MAX 3000.0f
typedef struct _pid_struct_t
{
  float kp;
  float ki;
  float kd;
	float i_band;
	float p_max;
  float i_max;
	float d_max;
  float out_max;
  
  float ref;      // Ŀ��ֵ
  float fdb;      // ʵ��ֵ
  float err[2];   // �����ϴ����

	float set;
  float get;
	
  float p_out;
  float i_out;
  float d_out;
  float output;
	void(*f_pid_init)(struct _pid_struct_t *pid, float kp, float ki, float kd, float p_max, float i_max, float d_max, float i_band,float out_max);			//������ʼ��pid
	void(*f_pid_clear)(struct _pid_struct_t *pid);
}pid_struct_t;

enum
{
  LAST  = 0,
  NOW   = 1,
};


void pid_param_init(pid_struct_t *pid,float kp,float ki,float kd,float p_max,float i_max,float d_max,float i_band,float out_max);
float pid_calc(pid_struct_t *pid, float get, float set);
void pid_clear(pid_struct_t *pid);			
float pid_calc_error(pid_struct_t *pid,float error);
void All_Pid_Configuration(pid_struct_t pid[]);							
void abs_limit(float *a, float ABS_MAX);

extern pid_struct_t pid[2];
extern pid_struct_t w_pid[2];

#endif

