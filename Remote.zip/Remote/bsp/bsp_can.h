#ifndef __BSP_CAN_H_
#define __BSP_CAN_H_

#include "can.h"

extern CAN_HandleTypeDef hcan1;
extern CAN_HandleTypeDef hcan2;

void can_filter_init(void);

#endif

