#include "pid.h"

pid_struct_t pid[2];
pid_struct_t w_pid[2];

void pid_param_init(pid_struct_t *pid, float kp, float ki, float kd, float p_max, float i_max, float d_max, float i_band, float out_max)
{
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;
    pid->i_band = i_band;
    pid->p_max = p_max;
    pid->i_max = i_max;
    pid->d_max = d_max;
    pid->out_max = out_max;
    pid->err[0] = pid->err[1] = 0;

    pid->f_pid_clear = pid_clear;
    pid->f_pid_clear(pid);
}

void abs_limit(float *a, float ABS_MAX)
{
    if (*a > ABS_MAX)
        *a = ABS_MAX;
    if (*a < -ABS_MAX)
        *a = -ABS_MAX;
}

float pid_calc(pid_struct_t *pid, float get, float set)
{
    pid->get = get;
    pid->set = set;
    pid->err[NOW] = set - get;

    pid->f_pid_clear = pid_clear;
    pid->f_pid_clear(pid);

    pid->p_out = pid->kp * pid->err[NOW];

    if (fabs(pid->err[NOW]) < pid->i_band)
    {
        pid->i_out += pid->ki * pid->err[NOW];
    }
    else
    {
        pid->i_out = 0;
    }
    pid->d_out = pid->kd * (pid->err[NOW] - pid->err[LAST]);

    abs_limit(&(pid->p_out), pid->p_max);
    abs_limit(&(pid->i_out), pid->i_max);
    abs_limit(&(pid->d_out), pid->d_max);
    pid->output = pid->p_out + pid->i_out + pid->d_out;
    abs_limit(&(pid->output), pid->out_max);

    pid->err[LAST] = pid->err[NOW];

    return pid->output;
}

static void pid_clear(pid_struct_t *pid)
{

    pid->p_out = 0;
    pid->i_out = 0;
    pid->d_out = 0;
    pid->output = 0;
}

float pid_calc_error(pid_struct_t *pid, float error)
{
    pid->f_pid_clear = pid_clear;
    pid->f_pid_clear(pid);

    pid->err[LAST] = pid->err[NOW];
    pid->err[NOW] = error;

    pid->p_out = pid->kp * pid->err[NOW];
    pid->i_out += pid->ki * pid->err[NOW];
    pid->d_out = pid->kd * (pid->err[NOW] - pid->err[LAST]);
    abs_limit(&(pid->p_out), pid->p_max);
    abs_limit(&(pid->i_out), pid->i_max);
    abs_limit(&(pid->d_out), pid->d_max);

    pid->output = pid->p_out + pid->i_out + pid->d_out;
    abs_limit(&(pid->output), pid->output);
    return pid->output;
}

void All_Pid_Configuration(pid_struct_t pid[])
{
	
	
	                                   //float kp, float ki, float kd, float p_max, float i_max, float d_max, float i_band, float out_max
    pid[SPEED].f_pid_init = pid_param_init;
    pid[SPEED].f_pid_init(&pid[SPEED],27.0f,0.0001f,0.001f, 14000, 1000.0f, 1000.0f, 2000.0f, 15000);

    pid[ANGLE].f_pid_init = pid_param_init;
    pid[ANGLE].f_pid_init(&pid[ANGLE], 26.0f,0,0.0003f, 14000, 1000.0f, 1000.0f, 2000.0f, 15000);
	
	w_pid[0].f_pid_init = pid_param_init;
	w_pid[0].f_pid_init(&w_pid[0],23.0f,1.0f, 0.0f, 1000, 200.0f, 100.0f, 20.0f, 8000);
	
	w_pid[1].f_pid_init = pid_param_init;
	w_pid[1].f_pid_init(&w_pid[1],23.0f,1.0f, 0.0f, 1000, 200.0f, 100.0f, 20.0f, 8000);
	
	
}

// void H_PID_INIT(void)
// {
//     w[SPEED].f_pid_init = pid_param_init;
//     pid_param_init(&w[SPEED], 2, 0, 0, 1000, 1000, 1000, 20, 2000);             
//     w[ANGLE].f_pid_init = pid_param_init;
//    w[ANGLE].f_pid_init(&w[ANGLE], 5.0f, 0.0f, 0.0f, 1000, 200.0f, 100.0f, 20.0f, 1200);
// }
