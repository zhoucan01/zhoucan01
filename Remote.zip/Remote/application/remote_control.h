/**
  ****************************(C) COPYRIGHT 2016 DJI****************************
  * @file       remote_control.c/h
  * @brief      ң����������ң������ͨ������SBUS��Э�鴫�䣬����DMA���䷽ʽ��ԼCPU
  *             ��Դ�����ô��ڿ����ж���������������ͬʱ�ṩһЩ��������DMA������
  *             �ķ�ʽ��֤�Ȳ�ε��ȶ��ԡ�
  * @note       
  * @history
  *  Version    Date            Author          Modification
  *  V1.0.0     Dec-26-2018     RM              1. ���
  *
  @verbatim
  ==============================================================================

  ==============================================================================
  @endverbatim
  ****************************(C) COPYRIGHT 2016 DJI****************************
  */
#ifndef REMOTE_CONTROL_H
#define REMOTE_CONTROL_H
#include "struct_typedef.h"
#include "bsp_rc.h"


#define SBUS_RX_BUF_NUM 36u

#define RC_FRAME_LENGTH 18u

#define RC_CH_VALUE_MIN         ((uint16_t)364)
#define RC_CH_VALUE_OFFSET      ((uint16_t)1024)
#define RC_CH_VALUE_MAX         ((uint16_t)1684)

/* ----------------------- RC Switch Definition----------------------------- */
#define SWITCH_UP                ((uint16_t)1)
#define SWITCH_MIDDLE               ((uint16_t)3)
#define SWITCH_DOWN              ((uint16_t)2)
#define switch_is_down(s)       (s == RC_SW_DOWN)
#define switch_is_mid(s)        (s == RC_SW_MID)
#define switch_is_up(s)         (s == RC_SW_UP)

#define WHEEL_MAX_RIGHT 660
#define WHEEL_MIN_LEFT -660

#define RC_CHANNEL_MAX 660
#define RC_CHANNEL_MIN -660

#define KEY_DOWN 0 
#define KEY_UP 1

#define FLAG_ON 0 
#define FLAG_OFF 1

#define REMOTE_MODE 0
#define KEYBORD_MODE 1

/* ----------------------- Data Struct ------------------------------------- */
typedef struct
{
	struct
	{ 
		short ch0;
		short ch1;
		short ch2;
	  short ch3;
	  char s_l;
		char s_r;
		long int wheel;
	}rc;
	
	struct 
	{
		short vx;
		short vy;
		short vz;
		unsigned char press_l;
		unsigned char press_r;
	}mouse;
	
	struct
	{
		unsigned short v;
		uint8_t key_W;
		uint8_t key_S;
		uint8_t key_A;
		uint8_t key_D;
		uint8_t key_Shift;
		uint8_t key_CTRL;
		uint8_t key_Q;
		uint8_t key_E;
		
		uint8_t key_R;
		uint8_t key_F;
		uint8_t key_G;
		uint8_t key_Z;
		uint8_t key_X;
		uint8_t key_C;
		uint8_t key_V;
		uint8_t key_B;
		
		uint8_t last_Z;
		uint8_t last_X;
		uint8_t last_C;
		uint8_t last_V;
		uint8_t last_Ctrl;
		
		uint8_t flag_Z;
		uint8_t flag_X;
		uint8_t flag_C;
		uint8_t flag_V;
		uint8_t flag_Ctrl;
		
		float vx;
		float vy;
		
	}keyboard;

} RC_ctrl_t;

/* ----------------------- Internal Data ----------------------------------- */

/**
  * @brief          remote control init
  * @param[in]      none
  * @retval         none
  */
/**
  * @brief          ң������ʼ��
  * @param[in]      none
  * @retval         none
  */
extern void remote_control_init(void);
/**
  * @brief          get remote control data point
  * @param[in]      none
  * @retval         remote control data point
  */
/**
  * @brief          ��ȡң��������ָ��
  * @param[in]      none
  * @retval         ң��������ָ��
  */
extern const RC_ctrl_t *get_remote_control_point(void);

extern uint8_t remote_source;
extern RC_ctrl_t rc_ctrl;


#endif
