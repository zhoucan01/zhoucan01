#include "CAN_recieve.h"
#include "struct_typedef.h"

moto_measure_t motor[2];

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{ 
    CAN_RxHeaderTypeDef rx_header;
    uint8_t rx_data[8];
    if (hcan->Instance == CAN1)
    {
        HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_header, rx_data); // receive can data
        switch (rx_header.StdId)
        {
        case 0x202:
            motor[0].msg_cnt++ <= 50 ? get_moto_offset(&motor[0], rx_data) : encoder_data_handle(&motor[0], rx_data);
            break;
				case 0x201:
					motor[1].msg_cnt++ <= 50 ? get_moto_offset(&motor[1], rx_data) : encoder_data_handle(&motor[1], rx_data);
            break;
				
				
				
        }
    }
    if (hcan->Instance == CAN2)
    {
        HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rx_header, rx_data); // receive can data
        switch (rx_header.StdId)
        {
        case 0x205:
            motor[1].msg_cnt++ <= 50 ? get_moto_offset(&motor[1], rx_data) : encoder_data_handle(&motor[1], rx_data);
            break;
        }
    }
}

static void get_moto_offset(moto_measure_t *ptr, uint8_t data[])
{
    ptr->ecd = (uint16_t)(data[0] << 8 | data[1]);
    ptr->offset_ecd = ptr->ecd;
}

void encoder_data_handle(moto_measure_t *ptr, uint8_t data[])
{
    ptr->last_ecd = ptr->ecd;
    ptr->ecd = (uint16_t)(data[0] << 8 | data[1]);
    ptr->speed_rpm = (int16_t)(data[2] << 8 | data[3]);
    ptr->given_current = (uint8_t)(data[4] << 8 | data[5]);
    ptr->temperate = data[6];

    if (ptr->ecd - ptr->last_ecd > 4096)
    {
        ptr->round_cnt--;
    }
    else if (ptr->ecd - ptr->last_ecd < -4096)
    {
        ptr->round_cnt++;
    }
    ptr->total_ecd = ptr->round_cnt * 8192 + ptr->ecd - ptr->offset_ecd;
    ptr->total_angle = ptr->total_ecd * 360 / 8192;
}

void set_motor_current( CAN_HandleTypeDef *hcan,uint32_t id_range, int16_t v1, int16_t v2, int16_t v3, int16_t v4 )
{

  CAN_TxHeaderTypeDef tx_header;
  uint8_t             tx_data[8];

  tx_header.StdId = id_range;
  tx_header.IDE   = CAN_ID_STD;
  tx_header.RTR   = CAN_RTR_DATA;
  tx_header.DLC   = 8;

 tx_data[0] = (v1>>8)&0xff;
 tx_data[1] =    (v1)&0xff;
 tx_data[2] = (v2>>8)&0xff;
 tx_data[3] =    (v2)&0xff;
 tx_data[4] = (v3>>8)&0xff;
 tx_data[5] =    (v3)&0xff;
 tx_data[6] = (v4>>8)&0xff;
 tx_data[7] =    (v4)&0xff;

 HAL_CAN_AddTxMessage(hcan, &tx_header, tx_data,(uint32_t*)CAN_TX_MAILBOX0);
}
