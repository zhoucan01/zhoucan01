/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * File Name          : freertos.c
 * Description        : Code for freertos applications
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2022 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "jdq.h"
#include "rng.h"
#include "stdio.h"
#include "tim.h"
float t;
float spd, a, w, b, rad;
int y = 0;
int num, speed;
float get_speed0,get_speed1;

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
osThreadId defaultTaskHandle;
osThreadId JDQHandle;
osThreadId REMOTEHandle;
osThreadId myTask04Handle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void const * argument);
void StartTask02(void const * argument);
void StartTask03(void const * argument);
void print_task(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory(StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize)
{
    *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
    *ppxIdleTaskStackBuffer = &xIdleStack[0];
    *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
    /* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
    /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
    /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
    /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
    /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* definition and creation of JDQ */
  osThreadDef(JDQ, StartTask02, osPriorityIdle, 0, 128);
  JDQHandle = osThreadCreate(osThread(JDQ), NULL);

  /* definition and creation of REMOTE */
  osThreadDef(REMOTE, StartTask03, osPriorityIdle, 0, 128);
  REMOTEHandle = osThreadCreate(osThread(REMOTE), NULL);

  /* definition and creation of myTask04 */
  osThreadDef(myTask04, print_task, osPriorityIdle, 0, 128);
  myTask04Handle = osThreadCreate(osThread(myTask04), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
    /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
 * @brief  Function implementing the defaultTask thread.
 * @param  argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* USER CODE BEGIN StartDefaultTask */
    /* Infinite loop */

    num = HAL_RNG_GetRandomNumber(&hrng);
    a = (num % 274 + 780) / 1000;
    if (a < 0.780f)
    {
        a = 1.040f;
    }
    // a = a / 1000;
    w = (num % 116 + 1884) / 1000;
    if (w < 1.884f)
        ;
    {
        w = 2.000f;
    }
    // w = w / 1000;
    b = 2.090f - a;
    for (;;)
    {
        //    num = HAL_RNG_GetRandomNumber(&hrng);
        //     a = (num % 274 + 780);
        //      if(a<780)
        //     {
        //         a = 1040;
        //     }
        //     a = a / 1000;
        //     w = (num % 116 + 1884);
        //     if(w<1884);
        //     {
        //         w =2000;
        //     }
        //     w = w / 1000;
        //     b = 2.090f - a;
				printf("%f,%d\n", -spd ,motor[1].speed_rpm);
        osDelay(10);
    }

  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_StartTask02 */
/**
* @brief Function implementing the JDQ thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTask02 */
void StartTask02(void const * argument)
{
  /* USER CODE BEGIN StartTask02 */
    /* Infinite loop */
	
	
    for (;;)
    {   // 隝机�??
        // t = t+1;
        // osDelay(1000);
        // spd = (a * sin(w * t) + b) * 9.55f;
        // spd = (1.03f * sin(2.0f * t) + 1.13f) * 9.55f;
        // rad = spd * 115;
			get_speed0=-motor[0].speed_rpm;
					get_speed1=-motor[1].speed_rpm;
			if(rc_ctrl.rc.s_r==SWITCH_UP)
			{
				
        if ( rc_ctrl.rc.s_l == 3)
        {
            speed = -800;
            spd = +spd;
        }
        else
        {
            speed = +800;
            spd = -spd;
        }
			}
//ֹͣģʽ
        if (rc_ctrl.rc.s_r == 1)
        {
					 motor[1].set_current = pid_calc(&pid[ANGLE], motor[1].speed_rpm, speed);
					

            motor[0].set_current = pid_calc(&pid[SPEED], motor[0].speed_rpm, speed);
					
            set_motor_current(&hcan1, 0x200,motor[1].set_current,  motor[0].set_current, 0, 0);
        }

        if (rc_ctrl.rc.s_r == 3)
        {
            motor[0].set_current = pid_calc(&w_pid[0], motor[0].ecd, motor[0].last_ecd);
					motor[1].set_current=pid_calc(&w_pid[1],motor[1].ecd,motor[1].last_ecd);
					// 
            set_motor_current(&hcan1, 0x200,motor[1].set_current ,motor[0].set_current, 0, 0);
            osDelay(10);
        }

				
				
			
				if(rc_ctrl.rc.s_l==1)
				{
				a=0.85;
					b=2.09-a;
				
				
				}
				if(rc_ctrl.rc.s_l==2)
				{
				a=1.03;
					b=2.09-a;
				
				}
				
				
					
				if(rc_ctrl.rc.s_l==3)
				{
				a=0.920;
					b=2.09-a;
				
				
				}
				
        if (rc_ctrl.rc.s_r == 2)
        {  
            //  motor[1].set_current = pid_calc(&pid[ANGLE], motor[1].last_ecd, motor[1].ecd);
            // a >= 0.780f && a <= 1.054f;
            // w >= 1.884f && w <= 2.000f;
            // 1 Rad/sec = 9.55 RPM
            // spd = (a * sin(w * t) + b) * 9.55f;
            //t = 1;
//            spd = (0.95f * sin(2.0f * t) + 1.14)   * 9.5f * 55;   //90
					spd = (a * sin(2.0f * t) + b)   * 9.3f * 86;   //90
			      spd = spd;
					set_speed=spd;
//					get_speed0=-motor[0].speed_rpm;
//					get_speed1=-motor[1].speed_rpm;
            // rad = spd * 90;
//            if (spd > 800)
//            {
//                spd = 800;
//                osDelay(20);
					
//            }
//            else  if (spd < 500)
//            {
//                spd = 500;
//                osDelay(20);
//            }
         // motor[0].set_current
            motor[0].set_current = pid_calc(&pid[SPEED], motor[0].speed_rpm, -spd);
						motor[1].set_current=pid_calc(&pid[ANGLE],motor[1].speed_rpm,-spd);
             set_motor_current(&hcan1, 0x200, motor[1].set_current,motor[0].set_current, 0, 0);
						//osDelay(10);
            // osDelay(1250);
        }
				
				
				//�糵�رպ���㿪ʼ�˶�
        if (rc_ctrl.rc.s_r != 2)
        {
            t = 0;
        }

        osDelay(1);
    }
  /* USER CODE END StartTask02 */
}

/* USER CODE BEGIN Header_StartTask03 */
/**
 * @brief Function implementing the REMOTE thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartTask03 */
void StartTask03(void const * argument)
{
  /* USER CODE BEGIN StartTask03 */
    /* Infinite loop */
    for (;;)
    {

        if (rc_ctrl.rc.ch0 > 650)
        { 

            osDelay(200);
            y++;
        }
        if (rc_ctrl.rc.ch0 < -650)
        {
             all_close();
            y = 0;
        }
        if (y == 0)
        {
            HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
        } 

        if (y == 1)
        {
            HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);	
            HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
        }

        if (y == 2)
        {
            HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
        }

        if (y == 3)
        {
            HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(K2_GPIO_Port, K2_Pin, GPIO_PIN_SET);
            //   HAL_GPIO_WritePin(L1_GPIO_Port, L1_Pin, GPIO_PIN_SET);
        }
//        if (y == 4)
//        {
//            HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(K2_GPIO_Port, K2_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(L1_GPIO_Port, L1_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(L2_GPIO_Port, L2_Pin, GPIO_PIN_SET);
//            //HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, GPIO_PIN_SET);
//        }
//        if (y == 5)
//        {
//            HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(K2_GPIO_Port, K2_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(L1_GPIO_Port, L1_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(L2_GPIO_Port, L2_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(M2_GPIO_Port, M2_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(N1_GPIO_Port, N1_Pin, GPIO_PIN_SET);
//        }
//        if (y == 6)
//        {
//            HAL_GPIO_WritePin(I1_GPIO_Port, I1_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(I2_GPIO_Port, I2_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(J2_GPIO_Port, J1_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(J2_GPIO_Port, J2_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(K1_GPIO_Port, K1_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(K2_GPIO_Port, K2_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(L1_GPIO_Port, L1_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(L2_GPIO_Port, L2_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(M1_GPIO_Port, M1_Pin, GPIO_PIN_SET);
//            HAL_GPIO_WritePin(M2_GPIO_Port, M2_Pin, GPIO_PIN_SET);
//        }
        if (y == 4)
        {
            HAL_GPIO_TogglePin(I1_GPIO_Port, I1_Pin);
            HAL_GPIO_TogglePin(I2_GPIO_Port, I2_Pin);
            HAL_GPIO_TogglePin(J1_GPIO_Port, J1_Pin);
            HAL_GPIO_TogglePin(J2_GPIO_Port, J2_Pin);
            HAL_GPIO_TogglePin(K1_GPIO_Port, K1_Pin);
            HAL_GPIO_TogglePin(K2_GPIO_Port, K2_Pin);
//            HAL_GPIO_TogglePin(L1_GPIO_Port, L1_Pin);
//            HAL_GPIO_TogglePin(L2_GPIO_Port, L2_Pin);
//            HAL_GPIO_TogglePin(M1_GPIO_Port, M1_Pin);
//            HAL_GPIO_TogglePin(M2_GPIO_Port, M2_Pin);
            y = 0;
        }
        osDelay(1);
    }
  /* USER CODE END StartTask03 */
}

/* USER CODE BEGIN Header_print_task */
/**
* @brief Function implementing the myTask04 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_print_task */
int bbbbbb;
__weak void print_task(void const * argument)
{
  /* USER CODE BEGIN print_task */
  /* Infinite loop */
  for(;;)
  {
//		bbbbbb++;
//		printf("%f,%f,%f\n",get_speed0,spd,get_speed1);
    osDelay(1);
  }
  /* USER CODE END print_task */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
int aaaa = 0;
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim == &htim5)
    {
        /* code */
        aaaa++;
        t = t + 0.01f;
    }
}
/* USER CODE END Application */
